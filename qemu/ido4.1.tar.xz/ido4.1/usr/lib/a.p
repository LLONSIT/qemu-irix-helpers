procedure a;
begin
write('ssss');
end;
