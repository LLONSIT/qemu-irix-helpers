@
  355   355   355
 6410  6428  6499
 6499  6539  6674
 6674  6692  6749
 6749  6754  6754
 6754  6764  6764
 6764  6772  6772
 6772  6793  6793
 6793  6821  6868
 6868  6876  6876
 6876  6885  6885
 6885  6894  6894
 6894  6920  7066
 7066  7095  7150
 7156  7194  7257
 7263  7296  7388
 7396  7443  7573
 7581  7655  7876
 7884  7921  8009
 8017  8059  8199
 8207  8235  8235
 8244  8284  8391
 8406  8448  8581
 8596  8636  8765
 8780  8803  8911
 8911  8954  9059
 9065  9088  9173
 9181  9228  9397
 9397  9408  9408
 9408  9423  9423
 9423  9443  9443
 9443  9491  9491
 9491  9530  9530
 9530  9550  9608
 9608  9628  9666
 9666  9695  9695
 9695  9734  9734
 9734  9748  9748
 9748  9775  9775
 9775  9807  9807
 9807  9850  9850
 9850  9866  9866
 9866  9908  9908
 9908  9934  9934
 9934  9960  9960
 9960  9981  9981
 9981 10000 10043
10043 10061 10061
10061 10093 10093
10093 10129 10129
10129 10154 10154
10154 10182 10182
10182 10215 10215
10215 10250 10250
10250 10274 10274
10274 10297 10297
10297 10317 10317
10317 10348 10348
10348 10393 10393
10393 10443 10443
10443 10479 10479
10479 10544 10544
10552 10576 10576
10586 10617 10617
10636 10665 10665
10674 10698 10741
10741 10783 10783
10783 10822 10822
10822 10846 10846
10846 10894 10894
10906 10967 11049
11049 11074 11074
11074 11099 11099
11099 11162 11162
11162 11185 11185
11185 11249 11249
11249 11293 11293
11303 11339 11339
11339 11378 11378
11388 11440 11440
11440 11482 11482
11482 11541 11541
11541 11568 11568
11568 11630 11630
11630 11672 11672
11684 11724 11724
11728 11759 11759
11759 11796 11796
11796 11846 12033
12057 12066 12066
12066 12075 12075
12075 12104 12104
12104 12138 12138
12138 12183 12183
12183 12219 12219
12219 12272 12272
12276 12312 12312
12312 12369 12369
12373 12428 12428
12432 12506 12506
12514 12577 12577
12583 12637 12637
12637 12689 12689
12689 12731 12731
12731 12772 12772
12772 12811 12811
12811 12829 12829
12829 12892 12892
12902 12941 12941
12951 13012 13012
13023 13109 13109
13109 13157 13157
13157 13216 13216
13216 13264 13264
13264 13296 13296
13296 13333 13333
13333 13374 13374
13374 13410 13479
13479 13526 13683
13683 13722 13800
13800 13859 13859
13859 13896 13896
13896 14064 14064
14064 14096 14096
14096 14109 14140
14140 14170 14201
14201 14221 14265
14265 14299 14404
14412 14430 14476
14480 14513 14513
14513 14581 14628
14636 14688 14688
14688 14735 14735
14747 14821 14821
14832 14893 14893
14893 14938 14938
14938 14981 15031
15031 15080 15151
15160 15213 15394
15400 15442 16756
16768 16821 16906
16918 16999 17125
17137 17182 17278
17290 17437 17787
17799 17885 18250
18262 18417 18720
18732 18898 19269
19281 19310 19442
19446 19473 19544
19544 19559 19722
19743 19754 19783
19783 19808 19808
19814 19873 19972
19980 20021 20125
20133 20169 20169
20169 20236 20328
20338 20387 20535
20547 20602 20602
20602 20645 20764
20772 20806 20984
20992 21040 21137
21149 21182 21260
21272 21341 21403
21415 21448 21448
21448 21533 21677
21702 21735 21810
21821 21847 21922
21959 22005 22166
22203 22237 22237
22245 22265 22265
22273 22309 22470
22507 22561 22636
22673 22701 22762
22774 22843 22843
22854 22916 22916
22927 22987 22987
22998 23035 23035
23041 23073 23174
23184 23229 23288
23298 23339 23387
23397 23438 23486
23496 23518 23570
23584 23613 23795
23802 23885 23885
23889 23915 24385
24397 24426 24626
24638 24676 24676
24676 24717 24915
24923 24974 25052
25062 25109 25186
25196 25225 25386
25396 25425 25703
25713 25753 25827
25836 25881 26167
26177 26210 26556
26566 26593 26640
26650 26677 26724
26735 26762 26809
26820 26848 26893
26903 26931 26976
26987 27033 27573
27580 27601 27649
27661 27679 27679
27685 27711 27711
27719 27789 27841
27849 27908 27908
27916 27948 27948
27956 27981 27981
27989 28046 28152
28160 28209 28324
28332 28370 28370
28378 28424 28665
28675 28727 28876
28888 28945 29025
29037 29074 29212
29234 29273 29286
29286 29335 29400
29409 29452 29517
29517 29553 29618
29626 29656 29656
29669 29728 29793
29799 29865 29935
29943 30011 30087
30099 30153 30210
30222 30272 30385
30397 30454 30516
30528 30601 30677
30685 30718 30817
30825 30885 30885
30893 30965 30965
30973 31075 31075
31087 31186 31328
31340 31382 31382
31382 31425 31425
31425 31466 31466
31466 31515 31638
31650 31698 31806
31818 31852 31852
31871 31913 31913
31921 31965 32211
32223 32284 32360
32381 32421 32558
32568 32595 32689
32699 32758 32957
32967 33015 33015
33015 33049 33111
33136 33169 33169
33178 33215 33215
33226 33292 33339
33347 33405 33405
33405 33439 33439
33439 33471 33548
33557 33618 33618
33627 33658 33740
33740 33775 33840
33840 33903 33903
33911 33954 33954
33966 34005 34080
34086 34172 34172
34180 34238 34268
34278 34317 34396
34406 34463 34463
34463 34509 34592
34601 34658 34777
34787 34840 34840
34850 34908 34986
34997 35024 35179
35189 35218 35271
35279 35347 35347
35355 35406 35406
35406 35426 35518
35530 35574 35592
35592 35655 35780
35792 35833 35922
35928 35956 36061
36073 36158 36158
36158 36196 36284
36284 36331 36450
36460 36523 36747
36755 36825 36846
36846 36867 36867
36867 36897 36990
36990 37030 37030
37030 37096 37096
37096 37160 37160
37160 37226 37226
37226 37359 37359
37359 37394 37394
37394 37425 37531
37543 37570 37676
37688 37757 37757
37757 37782 37829
37837 37861 37981
37993 38064 38064
38064 38128 38128
38128 38197 38197
38197 38261 38261
38261 38283 38283
38283 38400 38400
38400 38571 38571
38571 38617 38685
38697 38726 38775
38775 38817 38907
38917 38952 39136
39146 39189 39218
39229 39256 39310
39316 39339 39439
39439 39487 39736
39736 39800 39906
39906 40011 40165
40165 40235 40235
40235 40271 40518
40518 40553 40613
40619 40668 40668
40680 40719 40719
40719 40758 40758
40758 40798 40798
40798 40837 40837
40837 40879 40879
40879 40927 40927
40927 40946 40946
40946 41013 41013
41013 41071 41071
41071 41133 41133
41133 41161 41161
41161 41214 41214
41214 41284 41284
41284 41318 41318
41318 41355 41355
41355 41393 41393
41393 41434 41434
41434 41498 41498
41498 41523 41523
41523 41578 41578
41578 41619 41619
41619 41660 41660
41660 41732 41732
41732 41804 41804
41804 41847 41847
41847 41874 41874
41874 41889 41889
41889 41918 41966
41973 42005 42102
42110 42157 42157
42157 42203 42203
42203 42223 42305
42305 42328 42328
42328 42409 42477
42481 42532 42532
42532 42558 42605
42605 42696 42696
42696 42751 42751
42751 42784 42956
42966 43033 43051
43051 43127 43360
43378 43378 43378
Out of memory: %s
There is no more memory left in the system for compiling this program.
Internal Error Unknown Error Message %s
1) An internal error, while attempting to print an unavailable message
2) The error message file is inaccessible or has other problems
Unknown Signal %s
1) An unknown signal has been caught
2) 2 Nested signals
line
Warning: 
Fatal: 
Source not available
Too many errors... goodbye.
There is a limit of 30 errors before aborting.
Error: 
reserved
reserved
Unknown Control Statement
1) The line begins with a '#' and is not of the form:
	# <line_number> "<filename>"
2) Please compile this program with the preprocessor enabled.
Unknown character %s ignored
The character is not part of the source character set.
2.2.1
Unknown control character \%s ignored
The control character is not part of the source character set.
2.2.1
Illegal character %s in exponent
1) Digits or sign expected after 'e' or 'E'.
2) Digits are expected after sign in exponent.
3.1.3.1
Constant is out of range and may be truncated.
The constant is too large to be accurately represented and may be
truncated.  The limits are in the system include file limits.h.
2.2.4.2
Constant is out of range for a 32-bit data type, but accepted as written.
The constant is too large to fit in a 32-bit data type, but will be
accurately represented in a wider data type.  The value may be truncated,
depending on its context.  The limits are in the system include file
limits.h.
2.2.4.2
Character constant size out of range
1) No characters in a character constant.
2) More than 4 bytes in a character constant.
3.1.3.4
Wide character constant size out of range
1) No characters in the multibyte sequence (0 assumed).
2) More than 1 byte in the multi-byte sequence (only the first byte was converted).
3.1.3.4
Invalid multibyte character
4.10.7.2
Newline in string or character constant
1) Terminate your string or character constant with closing quotes.
2) Put a backslash before the newline.
3.1.3.4, 3.1.4
Octal character escape too large: %s > %s
1) Terminate end of octal sequence with a non-octal character.
2) Select a character value within the limits.
Value may be truncated
3.1.3.4, 3.1.4
Hex character escape too large: %s > %s
1) Terminate end of hex sequence with a non-hex character.
2) Select a character value within the limits.
Value may be truncated
3.1.3.4, 3.1.4
Unexpected End-of-file
1) Unterminated string or character constant
2) Missing closing comment marker (*/)
3) File system problems
Unrecognized escape sequence in string \%s
Recognized escape sequences are \a, \b, \f, \n, \r, \t, and \v.
Character will be treated as un-escaped.
3.9.2
Illegal octal digit %s
Octal constants, beginning with 0, must only have digits between 0 and 7,
inclusive.
3.1.3.2
Unable to open temporary file for compiling %s
1) TMPDIR environment variable is set to a directory that you have no
   permissions for.
2) The file system is full.
3) System errors beyond the scope of the compiler.
%s: Hangup
%s: Interrupt 
%s: Quit (ASCII FS)
%s: Illegal instruction (not reset when caught)
%s: Trace trap (not reset when caught)
%s: IOT instruction
Also SIGABRT, used by abort, replace SIGIOT in the future
%s: EMT instruction
Also SIGXCPU, Exceeded CPU time limit
%s: Floating point exception
%s: Kill (cannot be caught or ignored)
%s: Bus error
%s: Segmentation violation
%s: Bad argument to system call
%s: Write on a pipe with no one to read it
%s: Alarm clock
%s: Software termination signal from kill
%s: User defined signal 1
%s: User defined signal 2
%s: Death of a child
Power-fail restart
%s: Also SIGXFSZ, exceeded file size limit
%s: Window change
%s: Handset, line status change
%s: Sendablestop signalnot from tty
%s: Stop signal from tty
%s: Pollable event occurred
%s: Input/Output possible signal
%s: Urgent condition on IO channel
%s: Window size changes
%s: Virtual time alarm
%s: Profiling alarm
%s: Continue a stopped process
%s: To readers pgrp upon background tty read
%s: Like TTIN for output if (tp->t_local&LTOSTOP)
%s: Resource lost (eg, record-lock)
'auto' and 'register' are not allowed in an external declaration
3.7(10)
must have function type
3.7.1(30)
Functions cannot return arrays
3.7.1(33), 3.3.2.2
Declaration list not allowed
3.7.1(5)
Too many input files %s
The command line may contain only one file
cpp internal error: input stack underflow
cpp internal error: if stack underflow
Cannot open the file %s
No new-line character at the end of the file %s
2.1.1.2(30)
Fatal: Exceeded the limit of nesting level for #include file
Fatal: Exceeded the limit of nesting level for #include file.  This limit
is 200.
Fail to read the file %s
Cannot write the file %s
%s: %s: An if directive is not terminated properly in the file
%s: %s: nested comment
%s:%s: Illegal macro name %s; macro name shall be an identifier
%s:%s: Illegal preprocessing token sequence
3.8.3(35)
%s:%s: Illegal macro parameter name
%s:%s: Non-unique macro parameter name
3.8.3(18)
%s:%s: Missing ')' in parameter list for #define %s
%s:%s: Missing ')' in macro instantiation
%s:%s: Bad punctuator in the parameter list for #define %s
%s:%s: Macro %s redefined.
%s:%s: # operator should be followed by a macro argument name
%s:%s: Badly formed constant expression%s
3.4(9), 3.8
%s:%s: Division by zero in #if or #elif
3.8
unknown command line option %s
extraneous input/output file name %s
%s: %s: Unterminated string or character constant
A preprocessing string or character constant token was not
terminated.  Note that preprocessing directives are processed
after the source file has been divided into preprocessing tokens.
2.1.1.2(30) 3.1(18) 3.8
%s: %s: 
%s: %s: 
%s: %s: Unterminated comment
%s: %s: Unknown directive type %s
%s: %s: #elif or #else after #else directive
%s: %s: Bad identifier after the %s
%s: %s: #%s accepts only one identifier as parameter
3.8
%s: %s: Bad identifier after the %s
%s: %s: text following #%s violates the ANSI C standard.
3.8
%s: %s: Bad character %s occurs after the # directive.
3.8
%s: %s: the ## operator shall not be the %s token in the replacement list
3.8.3.3
%s: %s: the defined operator takes identifier as operand only.
3.8.1
%s: %s: Not in a conditional directive while using %s
%s: %s: Illegal filename specification for #include
%s: %s: Invalid file name %s for #include
%s: %s: Cannot open file %s for #include
%s: %s: Bad argument for #line command
%s: %s: #error %s
%s: %s: Tried to redefine predefined macro %s, attempt ignored
3.8.7(22)
%s: %s: Undefining predefined macro %s
3.8.7(22)
%s: %s: Undefined the ANSI standard library defined macro %s
4.1.2.1(9)
%s: %s: The number of arguments in the macro invocation does not match the definition
%s: %s: Illegal character %s in preprocessor if
%s: %s: Illegal character %s for number in preprocessor if
%s: %s: No string is allowed in preprocessor if
%s: %s: Not supported pragma %s
%s: %s: Not supported #pragma format
%s: %s: ANSI C does not allow #ident; %s
%s: %s: Not supported #ident format
This cpp extension accepts the following format:
#ident "any string"
%s: %s: Not supported #assert/#unassert format
This cpp extension accepts the following format:
#assert identifier
#assert identifier ( pp-tokens )
#unassert identifier
#unassert identifier ( pp-tokens )
%s: %s: Bad assertion predicate format
The correct syntax for this cpp extension is:
#assert identifier ( pp-token )
%s: %s: directive is an upward-compatible ANSI C extension
%s: This option requires an argument
%s: %s: A macro has expanded recursively more than %s times.  Further expansion will be disabled!  Use command-line option: -Wp,-max_rec_depth=depth to recurse deeper.
A status return from cpp to cfe
Syntax Error
The token read was unexpected.
Syntax Error -- cannot backup
The token read was unexpected.
Yacc stack overflow
The expression is too complicated to parse.
Trailing comma in enumerator list
The use of a trailing comma in an enumerator list is not standard C.  There
may be portability problems.
3.5.2.2
Empty declaration
Empty declarations are invalid in standard C.
3.5
%s declared, but not referenced.
redeclaration of '%s'; previous declaration at line %s in file '%s'
Identifier redeclared in the same scope/block.
3.1.2.3
'%s' undefined; reoccurrences will not be reported.
Non-function name referenced in function call.
3.3.2.2(18)
The number of arguments doesn't agree with the number in the declaration.
3.3.2.2(5)
'%s' section name longer than 8 characters.  Name truncated.
'%s' is already placed by pragma alloc_text.
Cannot write ucode file while compiling %s
1) The file system is full
2) Permissions problem
Must have corresponding formal argument for '%s'
Parameter found in the declaration part, but not in the argument list.
3.7.1(7)
Non-prototype declaration is an obsolescent feature.
The use of function definitions with separate parameter identifier
and declaration lists (not prototype-format parameter type and
identifier declarators) is an obsolescent feature.
3.9.5
Incompatible function declarations for %s
For two function types to be compatible, both shall specify compatible
return types.  Moreover, the parameter type lists, if both are present,
shall agree in the number of parameters and in use of the ellipsis
terminator; corresponding parameters shall have compatible types.  If
one type has a parameter type list and the other type is specified by
a function declarator that is not part of a function definition and
contains an empty identifier list, the parameter list shall not have
an ellipsis terminator and the type of each parameter shall be
compatible with they type that results from application of the default
argument promotions.  If one type has a parameter type list and the
other is specified by a function definition that contains a (possibly
empty) identifier list, both shall agree in the number of parameters,
and the type of each prototype parameter shall be compatible with the
type that results from application of the default argument promotions
to the type of the corresponding identifier.  (For each parameter
declared with function or array type, its type for these comparisons
is the one that results from conversion to a pointer type.  For each
parameter declared with qualified type, its type for these comparisons
is the unqualified version of its declared type.)  There you have it!
3.5.4.3(15)
Incompatible function return type for this function.
For two function types to be compatible, both shall specify compatible
return types.
3.5.4.3(15)
The number of parameters for function is different from the previous declaration
The parameter type lists, if both are present, shall agree in the
number of parameters and in use of the ellipsis terminator.
3.5.4.3(15)
Incompatible type for the function parameter
If both parameter type lists are present, corresponding
parameters shall have compatible types.
3.5.4.3(15)
Function %s is redeclared with an incompatible argument type (after default argument promotion), which could lead to undefined run-time behaviour.
The redeclaration could cause arguments at a call site to be passed 
inconsistently with what the function implementation expects, and
parameters would therefore be accessed erroneously when executing the
function body.  Note that a float argument is promoted to a double 
when passed (potentially through fp registers) to an unprototyped 
function.
3.5.4.3(15)
prototype and non-prototype declaration found for %s, ellipsis terminator not allowed
If one type has a parameter type list and the other type is specified
by a function declarator that is not part of a function definition and
contains an empty identifier list, the parameter list shall not have
an ellipsis terminator and the type of each parameter shall be
compatible with they type that results from application of the default
argument promotions.
3.5.4.3(15)
prototype and non-prototype declaration found for %s, the type of this parameter is not compatible with the type after applying default argument promotion
If one type has a parameter type list and the other type is specified
by a function declarator that is not part of a function definition and
contains an empty identifier list, the type of each parameter shall be
compatible with the type that results from application of the default
argument promotions.
3.5.4.3(15)
prototype declaration and non-prototype definition found for %s, the type of this parameter is not compatible with the type after applying default argument promotion
If one type has a parameter type list and the other is specified by a
function definition that contains a (possibly empty) identifier list,
both shall agree in the number of parameters, and the type of each
prototype parameter shall be compatible with the type that results
from application of the default argument promotions to the type of the
corresponding identifier.
3.5.4.3(15)
Empty declaration specifiers
Standard C requires at least a storage class specifier, type specifier,
or a type qualifier in declarations.  'extern int' assumed.
3.5
Can't write to the file %s
1) The output file cannot be opened for writing.
2) Out of file space.
Duplicate '%s'
typedef, extern, static, auto, register, const, volatile may not
appear more than once in the same specifier list or qualifier list.
Duplicate occurrence ignored.
3.5.1(10) , 3.5.3(5)
Null input
There is nothing to compile.
Illegal type combination
3.5.2
Missing ';' at end of structure / union member declaration
In standard C, each member declaration must be terminated by a ';'.  A
terminating ';' is assumed.
3.5.2.1
Missing member name in structure / union
In standard C, each member declaration have a member name.  The missing
member is assumed to not exist.
3.5.2.1
This variable is initialized twice.
Neither 'const' or 'volatile' have any effect on function results.
Qualifiers only apply to expressions designating an object that
can be altered or examined.
3.5.3(10)
An integer constant expression is required here.
The expression that defines the value of an enumeration constant
shall be an integral constant expression that has a value
representable as an int.
3.5.2.2(28)
(previous declaration of '%s' at line %s in file '%s')
Must be an integer type greater than zero.
The array size must be either a char, signed or unsigned integer or
an enumerated type with a value greater than zero.
3.5.4.2
Array size cannot be a long long.
Arrays with more than 2^32 elements are not yet supported.
The array size must be either a char, signed or unsigned integer or
an enumerated type with a value greater than zero.
3.5.4.2
bit-field '%s' width is not an integer constant
The expression that specifies the width of a bit-field shall be an
integral constant expression.
3.5.2.1(15)
bit-field '%s' width is negative
The expression that specifies the width of a bit-field shall be
non-negative.
3.5.2.1(15)
bit-field '%s' type required to be int, unsigned int, or signed int.
A bit-field shall have type int, unsigned int, or signed int.
3.5.2.1(30)
bit-field %s's type not integer.
Non-scalar type or pointer type to a non-object for increment or decrement operator.
The operand of the prefix/postfix increment or decrement operator shall have scalar type; if it is of pointer type, it must point to an object.
3.3.2.4(37), 3.3.3.1(25)
Assign value to a function type.
An assignment operator shall have a modifiable lvalue as its left operand.
3.2.2.1(5)
Assign value to an array.
An assignment operator shall have a modifiable lvalue as its left operand.
3.3.2.4(36), 3.3.3.1(24), 3.2.2.1(5)
Change value for variable of incomplete type.
The operand of increment and decrement operator shall be a modifiable
scalar lvalue.  An assignment operator shall have a modifiable lvalue
as its left operand.
3.3.2.4(36), 3.3.3.1(24), 3.2.2.1(5)
This expression is not an lvalue.
3.2.2.1
Modified an rvalue.
3.2.2.1
Change value for constant variable.
The operand of increment and decrement operators shall be modifiable
scalar lvalues.  An assignment operator shall have a modifiable lvalue
as its left operand.
3.3.2.4(36), 3.3.3.1(24), 3.2.2.1(5)
Change value for constant field of a struct or union.
An assignment operator shall have a modifiable lvalue as its left operand.
3.3.2.4(36), 3.3.3.1(24), 3.2.2.1(5)
Dereferenced a non-pointer.
The operand of the unary * operator shall have pointer type.
3.3.3.2(39)
The operand of the unary + or - operator shall have arithmetic type.
3.3.3.3(6)
The operand of the unary ~ operator shall have integral type.
3.3.3.3(6)
The operand of the unary ! operator shall have scalar type.
3.3.3.3(6)
Constants must have arithmetic type.
3.1.3
Bad type name for cast operator
The type name for the cast operator should either be void or a
qualified or unqualified scalar type.
3.3.4(22)
Improper cast of non-scalar type expression.
The operand for the cast operator shall be of scalar type.
3.3.4(23)
Cast a pointer into a non-integral type.
A pointer may be converted to an integral type.
3.3.4(31)
Cast a non-integral type into a pointer.
An integral type may be converted to a pointer.
3.3.4(31)
Duplicate member '%s'
Two members of a struct may not have the same name.
3.1.2.2(7,25)
Invalid constant expression.
Constant expressions shall not contain assignment, increment, decrement,
function-call, or comma operators, except when they are contained within
the operand of the sizeof operator.
3.4(9)
Constant expressions must be derived from a constant value or a constant
variable.
3.4
Dangerous operand of '&'.
The operand of the unary & operator shall be either a function
designator or an lvalue that designates an object that is not a
bit-field and is not declared with the register storage-class
specifier.  This operand is NOT an lvalue, but we let it pass.
Note that a segmentation error with possible core dump will result
when the resulting address does not denote a valid (declared)
storage location.  This feature will be discontinued in future
releases of the compiler!
3.3.3.2(36)
Unacceptable operand of '&'.
The operand of the unary & operator shall be either a function
designator or an lvalue that designates an object that is not a
bit-field and is not declared with the register storage-class
specifier.
3.3.3.2(36)
'&' before array or function; ignored
Unacceptable operand of sizeof operator.
The sizeof operator shall not be applied to an expression that has
function type or an incomplete type, to the parenthesized name of such
a type, or to an lvalue that designates a bit-field object.
3.3.3.4
Unacceptable operand of a multiplicative operator.
Each of the operands of a multiplicative operator shall have arithmetic type.
3.3.5(18)
Unacceptable operand of the remainder operator
Each of the operands of the remainder (%) operator shall have integral type.
3.3.5(18)
Unacceptable operand of '+'.
For the + operator, either both operands shall have arithmetic type, or
one operand shall be a pointer to an object type and the other shall
have integral type.
3.3.6(39)
Unacceptable operand of '-'.
For the subtraction operator, one of the following shall hold: both operands
have arithmetic type; operands are pointers to qualified or unqualified
versions of compatible object types; or the left operand is a pointer
to an object type and the right operand has integral type.
3.3.6(39)
Unacceptable operand of shift operator.
Each of the operands of bitwise shift operators shall have integral type.
3.3.7(9)
Unacceptable operand of relational operator.
For relational operators, one of the following shall hold: both
operands have arithmetic type; both operands are pointers to qualified
or unqualified versions of compatible object types; or both operands
are pointers to qualified or unqualified versions of compatible
incomplete types.
3.3.8(32)
Unacceptable operand of == or !=
For the == or != operator, one of the following shall hold: both operands
are pointers to qualified or unqualified versions of compatible types; one
operand is a pointer to an object or incomplete type and the other is a
pointer to a qualified or unqualified version of void; or one operand is
a pointer and the other is a null pointer constant.
3.3.9(21)
Unacceptable operand of &.
Each of the operands shall have integral type.
3.3.10(7)
Unacceptable operand of ^.
Each of the operands shall have integral type.
3.3.11(18)
Unacceptable operand of |.
Each of the operands shall have integral type.
3.3.12(30)
Unacceptable operand of &&.
Each of the operands shall have scalar type.
3.3.13(7)
Unacceptable operand of ||.
Each of the operands shall have scalar type.
3.3.14(20)
Unacceptable operand of conditional operator.
The first operand of conditional operator shall have scalar type.  One
of the following shall hold for the second and third operands:
both operands have arithmetic type; both operands have compatible
structure or union types; both operands have void type; both operands
are pointers to qualified or unqualified versions of compatible types;
one operand is a pointer and the other is a null pointer constant; or
one operand is pointer to an object or incomplete type and the other
is a pointer to a qualified or unqualified version of void.
3.3.15
Duplicate label '%s'
A label name can only occur once in a function.
3.1.2.1(25)
Division by zero.
3.3.5
Subscripting a non-array.
3.3.2.1
Subscripting an array of incomplete type which is not an object type.
The element of the array shall have an object type.
3.3.2.1
Should only subscript an array with an integral expression
3.3.2.1
Subscripting an unbounded array
3.3.2.1
Array index out of range
3.3.2.1
Selector requires struct/union pointer as left hand side
In K&R mode the expression is implicitly converted to the '.' selector
for a struct/union left-hand side.
3.3.2.3
Selector requires struct/union as left hand side
In K&R mode the expression is implicitly converted to the '->' selector
for a struct/union pointer left-hand side.
3.3.2.3
member of structure or union required
3.3.2.3
types have different qualifier specifications
For two qualified types to be compatible, both shall have the
identically qualified version of a compatible type; qualified
and unqualified versions of a type are distinct types.  For two
types to be compatible their types must be the same.
3.5.3(26)
Incompatible array type due to different array size
For two array types to be compatible, both shall have compatible element
types; if both size specifiers are present, they shall have the
same value.
3.5.4.2(11)
Incompatible array type due to incompatible element type
For two array types to be compatible, both shall have compatible element
types.
3.5.4.2(11)
Incompatible pointer type assignment
The type pointed to by the left-hand side of simple assignment
statement is incompatible with the type pointed to by the right-hand side.
3.3.16.1, 3.5.4.1(21)
Incompatible base type of pointer type
K&R feature.
Type %s of %s is incompatible with type %s of %s
Incompatible types can be resolved by casting or by other means.
3.3.16.1
illegal combination of pointer and integer
Assigning an integral expression to a pointer is a bad practice.
Type for %s is incompatible with %s
Incompatible types can be resolved by casting or by other means.
3.1.2.6
Bad operand type for += or -=
3.3.16.2(26)
A case or default label appears outside a switch statement
A case or default label shall appear only in a switch statement.
3.6.1
The controlling expression of the if statement is not scalar type
The controlling expression of an if statement shall have scalar type.
3.6.4.1
The controlling expression of switch statement is not integral type
The controlling expression of an switch statement shall have integral type.
3.6.4.2(20)
The case label is not an integral constant expression
The case label shall be an integral constant expression.
3.6.4.2(22)
Duplicate case label in the same switch statement
No two of the case constant expressions in the same switch statement
shall have the same value after conversion.
3.6.4.2(22)
More than one default label in the same switch statement
There may be at most one default label in a switch statement.
3.6.4.2(23)
The controlling expression of the iteration statement is not scalar
type
The controlling expression of a iteration statement shall have scalar
type.
3.6.5.1
label '%s' used, but not defined
The identifier in a goto statement shall name a label located
somewhere in the enclosing function.
3.6.6.1
A continue statement shall appear only in or as a loop body
3.6.6.2
A break statement shall appear only in or as a switch body or loop body
3.6.6.3
A return statement with an expression should not appear
in a function '%s', whose return type is void
3.6.6.4(24)
A return statement without an expression appears in a
function '%s', whose return type is not void
If a return statement without an expression is executed, and the value
of the function call is used by the caller, the behavior is undefined.
3.6.6.4(33)
Internal Error: statement stack underflow
Long double not supported; double assumed.
Long float not standard; double assumed.
Only 'register' allowed in parameter declaration
The only storage-class specifier that shall occur in a parameter
declaration is 'register'; illegal storage class ignored.
3.5.4.3(25)
Name(s) without types in a function declaration
An old-style function declaration is not allowed to have names
in the parameter list; useless names ignored
3.5.4.3(26)
Functions cannot return functions
3.7.1(33), 3.3.2.2
Functions cannot return a non-object type
3.3.2.2
enum declaration must contain enum literals
Although structs or unions may delay the declaration of their members,
a similar construction with enum does not exist and is not necessary,
as there can be no mutual dependencies between the declaration of an
enumerated type and any other type.
3.5.2.3(27)
Register qualification has no effect for this type of object
Register declarations for array, struct, and function types have
no effect.
3.5.1(16), 3.5.1(19)
Functions cannot be declared 'register'
The declaration of an identifier for a function that has block
scope shall have no explicit storage-class specifier other than
'extern'.
3.5.1(19)
'%s' cannot be initialized
The type of the entity to be initialized shall be an object type
or an array of unknown size.
3.5.7(32)
Cannot initialize 'extern' variable '%s' within a function
If the declaration of an identifier has block scope, and the
identifier has 'extern' or 'static' linkage, the declaration
shall have no initializer for the identifier; initialization
allowed anyway.
3.5.7(35)
initializing an 'extern' is an ANSI C extension
conflicting declarations for '%s'
'static' and 'extern' declarations conflict.  Which is meant?
3.1.2.2(15), 3.1.2.2(27)
Too many initial values for '%s'
3.5.7(1)
incompatible types in initialization
3.3.16(35)
redefinition of '%s'; previous definition at line %s in file '%s'
Identifier redeclared in the same scope/block.
3.1.2.3
bit-fields as members of a union are an ANSI C invention.
storage size for '%s' isn't known
type mismatch in initialization
Missing braces in a union initialization or illegally formed
initialization.
3.5.7(5)
union '%s' only allowed one initializer for the first member
3.5.7(5)
width of '%s' exceeds its type
the specified bitfield width is too large to be contained within a
bitfield type.
structure has no member named '%s'
This is allowed for compatibility with AT&T pcc-based compilers.
Reference of an expression of void type or an incomplete type.
3.2.2.1
element size of an array shall not be zero
3.2.2.5(25)
invalid combination of type specifiers
Although order is unimportant, not all type specifiers can occur together.
3.5.2
declaration must at least declare an identifier, tag, or the member of an enumeration
3.5(16)
at most one storage class may be given in the declaration
Duplicate occurrence ignored.
3.5.1(10)
size of function's return type is zero
The return type of a function must be void or an object type other than array.
3.7.1(33)
Expecting an integral return type from the main function
identifier missing from parameter declaration
Prototypes for function definitions require identifiers in parameter
declarations.
3.7.1(4)
only 'register' allowed for storage class for parameters
The declarations in the declaration list shall contain no storage class
other than 'register', and no initializations.
3.7.1(10)
parameters declarations can not have initializations
3.7.1(10)
only one instance of 'void' allowed in the parameter list
'void' must occur by itself (specifying that the function has no parameters).
3.5.4.3(1)
%s must have function type
1) An argument list must be explicitly present in the declarator; it cannot
   be inherited from a typedef (3.5.4.3).
2) The declarator is not a function.
3.7.1(30)
Illegal hexadecimal constant
You have no digits after the 0x or 0X.  0x0 assumed.
3.1.3.2
value overflows its type in this context.  Value is set to be '%s'!
3.2.1.4
value is outside range representable for type '%s'
missing member name
K&R mode permits a missing member name; otherwise, only bitfields can omit
the member name.
3.5.2.1(10)
useless keyword or type name in declaration
Type was ignored.
'%s' declared within and is limited to this function prototype
Possible program error, since parameter type checking will always fail
unless the type declaration is visible to the caller.
3.1.2.1(35)
Extra spaces within operator, %s assumed
In ANSI C, the compound assignment operator cannot have embedded
white space characters.
3.1.5
missing size for array '%s'
Incomplete types permitted for identifiers with internal or
external linkage, but not automatic linkage.
3.1.2.5(10)
can't jump into (from outside of) the body of a 'try' or into either type of handler
'%s' missing, please #include excpt.h
excpt.h required to declare exception statements, intrinsics or compiler
runtime names.
local function declarations cannot be 'static'
A function declaration can only contain the storage-class 'static'
if it is at file scope.  Declaration made 'extern'.
3.5.1(19)
static function '%s' declared and referenced, but not defined.
If an identifier declared with internal linkage is used in an
expression (other than as a part of the operand of a sizeof
operator), there shall be exactly one external definition for
the identifier in the translation unit.
3.7(12)
pragma argument '%s' must be declared prior to being used in a pragma
Pragma name ignored.
Pragma not supported
'%s' not enabled as intrinsic
It may have already appeared in a function pragma, or never occurred in
an intrinsic pragma.
'%s' is already enabled as an intrinsic
weak definition for '%s' is later redefined; pragma weak ignored.
definition of primary name '%s' not found; pragma weak ignored.
definition of secondary name '%s' not found; pragma weak ignored.
primary name '%s' is declared as a common or external, and is not defined 
with initial value within this file; pragma weak ignored.
useless '%s' storage class ignored
array of functions not allowed
The element type must be an object type representing a region
of data storage which can represent values.
3.1.2.5(23)
array of voids not allowed
The element type must be an object type representing a region
of data storage which can represent values.
3.1.2.5(23)
argument for pragma pack must be an integer constant; pragma ignored
'%s' has wrong tag type.
Identifier redeclared in the same scope/block.
3.1.2.3
missing dimension bound
For multidimensional arrays, the constant bounds of the array may be
omitted only for the first member of the sequence.
3.1.2.5(23)
Internal error in parameters to function substr; loc: '%s'; len: '%s'.
Internal error in parameters to function insertstr; indx: '%s'.
Internal error in function get_tag_name; input is a non-tagged type.
Internal error in function gen_type_str -- not a type tree '%s'
Cannot open file '%s'
Prototype should be moved after tag or a typedef declaration.
Please look for comments in the extracted header file.
The extracted header file includes prototypes for static functions,
which should be removed, if you wish to include the header in a source file
other than the originator.
ANSI C requires formal parameter before "..."
This extension is meant to be used for compatibility with varargs.h
3.5.4.3(35)
syntax error: "&..." invalid
extension used to access "..." formal arguments.
function '%s' initialized like a variable
The type of entity to be initialized shall be an object type or an
array of unknown size.
3.5.7(31)
initializer not an array aggregate
The initializer for an object that has aggregate type shall be a
brace-enclosed list of initializers for the members of the aggregate,
written in increasing subscript or member order.
3.5.7(20)
'%s' type is incomplete; cannot initialize
Was the struct ever defined?
3.5.7.(31)
'%s' is not standard ANSI.
This keyword/type is not defined in strict ANSI mode.
3.1.1
not a legal asm string
The first operand of an asm string should be, after argument substitution,
a legal assembly string.
The -float option will be ignored in ANSI mode.
The -float option is ignored, since otherwise program semantics would
violate the ANSI standard.  In particular, fp constants are always
'double' with ANSI-C, while with -float the type of fp constants will
depend on the context and may be 'float'.
ANSI C support unavailable with C compiler bundled with RISC/os
The C compiler bundled with RISC/os does not support ANSI C.  ANSI
C support requires a separate license.
Ignored invalid warning number(s) in -woff option, %s%s !
Warning numbers must be in the range %s to %s.
The set of warning numbers in cfe is disjoint from the set of warning numbers
in accom, since accom warnings cannot be mapped one-to-one to cfe warnings.
'%s' not handled as an intrinsic due to incompatible argument types .
'__unalign' only qualifies pointers
'__unalign' indicates the object pointed at by pointer is unaligned (e.g.,
int * __unalign p).  This is an extension to ANSI C and like 'volatile'
and 'const' can follow the '*' in pointer declarations, but unlike both
cannot qualify a base type.
index expression is an anachronism
ANSI C++ doesn't support array index expressions in delete.
5.3.4
member cannot be of function or incomplete type.
3.5.2.1(12)
Illegal lint option, '%s', is ignored.
cannot open header message buffer file
cannot write header message buffer file
cannot read header message buffer file
cannot seek in header message buffer file
struct/union/enum '%s' is used, but not defined
static '%s' unused
nonportable character comparison (chars may be signed or unsigned)
redundant comparison of unsigned with constant expression
redundant statement, control flow cannot reach this statement
'%s' may be used before set
function parameter '%s' is not used in function '%s'
'%s' can be const qualified, since it is not set within its lifetime.
'%s' is not used in function '%s'
'%s' set but unused in function '%s'
control may fall through %s statement
function '%s' has return(e); and return;
function '%s' may return random value to place of invocation %s
label without goto: '%s'
width of %s constant is smaller than size of type (%s)
explicit conversion from '%s' to '%s' %s
implicit conversion from '%s' to '%s' %s
'%s' may be indistinguishable from '%s' due to internal name truncation
Promoted formal parameter and promoted argument have incompatible types
No prototype for the definition of '%s' %s
       (as included in %s)
==============
unsupported language linkage
string-literal specifies an unsupported linkage
7.4(1)
No prototype for the call to %s
To achieve better type-checking, there should be a full prototype for
the function being called.
3.5.4.3
'inline' only applies to function declarations
leave statment can occur only within try body
Microsoft extension
Use of a Microsoft extension detected without usage of the
compiler option -msft.
No parameter mentioned
A file with no declarations or definitions is accepted as an extension to ANSI C
The translation unit must contain at least one external definition.
3.7
Incompatible signed and unsigned version of a type
Yacc initialization error
Internal error: yacc cannot initialize itself.
The cfe option %s may not be in future releases.  We suggest that you not use this option!
Incompatible char and unsigned char versions of a type
Lshift with undefined behaviour.
Lshift with a negative right operand, or a right operand that is greater 
than or equal to the width in bits of the promoted left operand, results 
in undefined behaviour.
3.3.7(11)
useless type name in declaration, possibly a semicolon is missing.
Type was ignored.
constant initializer expression is invalid (refers to automatic variables).
All the expressions in an initializer for an object that has static storage
duration or in the initializer list for an object that has aggregate or
union type shall be constant expressions.  Otherwise, unexpected results 
may occur.
3.5.7(32) and 3.4
